import java.sql.*;
import javax.swing.*;
public class ConnectionDoc {
    
     Connection conn= null;
    public static Connection ConectorDb(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn =DriverManager.getConnection("jdbc:mysql://localhost/zhsm1","root","");
            return conn;
       }catch (Exception e){
           JOptionPane.showMessageDialog(null, e);
            return null;
       }
    }
    
}
