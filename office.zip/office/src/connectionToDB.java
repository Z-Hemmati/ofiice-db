import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
public class connectionToDB {
    
    Connection conn= null;
    public static Connection ConectorDb(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn =DriverManager.getConnection("jdbc:mysql://localhost/zhsm","root","");
            return conn;
       }catch (ClassNotFoundException e){
           JOptionPane.showMessageDialog(null, e);
           Logger.getLogger(connectionToDB.class.getName()).log(Level.SEVERE, null, e);
            return null;
       } catch (SQLException ex) {
            Logger.getLogger(connectionToDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
}
